print("Hello World")

# Integer Data Type
a=12
print(a)
print(type(a))

#float Data type
b=16.88
print(type(b))
print(b)

#Complex Data type
c= 3+8j
print("this is the data type of c" + str(type(c)))

# String Data type
d="e"
print(type(d))

e="Engineering Era"
print(e)
print(type(e))

#Sequence Data type

#List
f=[1,2,4,3,7,9,2,3]
g=["abc","def","abc","ghh"]
print(g)
print(f)
print("this is the data type of List" + str(type(f)))

#Tupple
h=(1,2,3,4,5,6,8,4,2)
print(h)
print("this is the data type of Tupple " + str(type(h)))


#Set DAta type

k={"abc","vvv","abc","hik","ahhh",1,2,4,6,7,2,9}
print(k)

#Dictionary DAta type
p={1:"a",2:"b",7:"u",4:"y"}
print(p)